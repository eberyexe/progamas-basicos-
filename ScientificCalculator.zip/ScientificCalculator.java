
import java.util.Scanner;
import java.lang.Math;

public class ScientificCalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Escolha uma operação:");
            System.out.println("1: Adição");
            System.out.println("2: Subtração");
            System.out.println("3: Multiplicação");
            System.out.println("4: Divisão");
            System.out.println("5: Seno");
            System.out.println("6: Cosseno");
            System.out.println("7: Tangente");
            System.out.println("8: Logaritmo");
            System.out.println("9: Exponencial");
            System.out.println("0: Sair");
            int choice = scanner.nextInt();

            if (choice == 0) {
                break;
            }

            switch (choice) {
                case 1:
                    System.out.print("Digite o primeiro número: ");
                    double add1 = scanner.nextDouble();
                    System.out.print("Digite o segundo número: ");
                    double add2 = scanner.nextDouble();
                    System.out.println("Resultado: " + (add1 + add2));
                    break;
                case 2:
                    System.out.print("Digite o primeiro número: ");
                    double sub1 = scanner.nextDouble();
                    System.out.print("Digite o segundo número: ");
                    double sub2 = scanner.nextDouble();
                    System.out.println("Resultado: " + (sub1 - sub2));
                    break;
                case 3:
                    System.out.print("Digite o primeiro número: ");
                    double mul1 = scanner.nextDouble();
                    System.out.print("Digite o segundo número: ");
                    double mul2 = scanner.nextDouble();
                    System.out.println("Resultado: " + (mul1 * mul2));
                    break;
                case 4:
                    System.out.print("Digite o primeiro número: ");
                    double div1 = scanner.nextDouble();
                    System.out.print("Digite o segundo número: ");
                    double div2 = scanner.nextDouble();
                    if (div2 != 0) {
                        System.out.println("Resultado: " + (div1 / div2));
                    } else {
                        System.out.println("Erro: Divisão por zero!");
                    }
                    break;
                case 5:
                    System.out.print("Digite o ângulo em graus: ");
                    double angle = scanner.nextDouble();
                    System.out.println("Resultado: " + Math.sin(Math.toRadians(angle)));
                    break;
                case 6:
                    System.out.print("Digite o ângulo em graus: ");
                    double cosAngle = scanner.nextDouble();
                    System.out.println("Resultado: " + Math.cos(Math.toRadians(cosAngle)));
                    break;
                case 7:
                    System.out.print("Digite o ângulo em graus: ");
                    double tanAngle = scanner.nextDouble();
                    System.out.println("Resultado: " + Math.tan(Math.toRadians(tanAngle)));
                    break;
                case 8:
                    System.out.print("Digite o número: ");
                    double logNumber = scanner.nextDouble();
                    System.out.println("Resultado: " + Math.log(logNumber));
                    break;
                case 9:
                    System.out.print("Digite a base: ");
                    double base = scanner.nextDouble();
                    System.out.print("Digite o expoente: ");
                    double exponent = scanner.nextDouble();
                    System.out.println("Resultado: " + Math.pow(base, exponent));
                    break;
                default:
                    System.out.println("Opção inválida! Tente novamente.");
            }
        }
        scanner.close();
    }
}
